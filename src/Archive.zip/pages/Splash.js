const Splash = () => {
  return <h1>This is the splash page - to be later put in Suspense component</h1>;
};

export default Splash;
